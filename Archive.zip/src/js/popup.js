import $ from 'jquery';
const axios = require('axios').default;

$(document).ready(function() {
    axios.get('https://jsonplaceholder.typicode.com/todos/1')
    .then(response => {
        console.log(response);
    })
    .catch(err => {
        console.log(err);
    })
});